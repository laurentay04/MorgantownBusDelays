package com.grace.bus_delay_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusDelayTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
